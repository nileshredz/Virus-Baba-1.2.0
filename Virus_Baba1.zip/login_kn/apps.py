from django.apps import AppConfig


class LoginKnConfig(AppConfig):
    name = 'login_kn'
