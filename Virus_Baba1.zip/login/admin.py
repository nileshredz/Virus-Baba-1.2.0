from django.contrib import admin
from . models import Login_new


admin.site.register(Login_new)
