from django.apps import AppConfig


class LoginMrConfig(AppConfig):
    name = 'login_mr'
