from django.apps import AppConfig


class LoginHiConfig(AppConfig):
    name = 'login_hi'
